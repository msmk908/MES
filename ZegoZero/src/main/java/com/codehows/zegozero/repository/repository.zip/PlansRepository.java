package com.codehows.zegozero.repository;

import com.codehows.zegozero.entity.Plans;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlansRepository  extends JpaRepository<Plans, Integer> {
}
