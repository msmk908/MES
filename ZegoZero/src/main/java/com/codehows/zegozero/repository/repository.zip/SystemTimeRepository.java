package com.codehows.zegozero.repository;

import com.codehows.zegozero.entity.System_time;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SystemTimeRepository  extends JpaRepository<System_time, Integer> {
}
