package com.codehows.zegozero.repository;

import com.codehows.zegozero.entity.Finish_product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FinishProductRepository extends JpaRepository<Finish_product, Integer> {
}
